import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
public class LivroService {
    @Autowired
    private LivroRepository livroRepository;

    public List<Livro> listarTodos() {
        return livroRepository.findAll();
    }

    public Livro salvar(Livro livro) {
        return livroRepository.save(livro);
    }

    public Livro atualizar(Long id, Livro livro) {
        Livro existente = livroRepository.findById(id).orElseThrow();
        existente.setTitulo(livro.getTitulo());
        existente.setIsbn(livro.getIsbn());
        existente.setCopiasDisponiveis(livro.getCopiasDisponiveis());
        return livroRepository.save(existente);
    }

    public void deletar(Long id) {
        livroRepository.deleteById(id);
    }
}